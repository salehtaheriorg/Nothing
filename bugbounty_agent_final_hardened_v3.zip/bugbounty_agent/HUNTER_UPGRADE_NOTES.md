# Hunter Upgrade Notes

این نسخه روی کیفیت تشخیص تمرکز دارد، نه صرفاً افزایش تعداد candidateها.

## Param Miner
- baseline چندنمونه‌ای و مقایسه‌ی differential حفظ شده است.
- تغییر جزئی طول/بدنه به‌تنهایی finding محسوب نمی‌شود.
- candidate باید در درخواست تکراری قابل بازتولید باشد.
- candidateها به‌عنوان «Hidden Parameter Candidate» ثبت می‌شوند، نه vulnerability قطعی.
- برای candidateهای معنادار، follow-up hunterها به‌صورت idempotent صف می‌شوند.

## XSS
- reflection قبل از ثبت candidate بررسی contextual می‌شود.
- HTML-escaped reflection به‌عنوان XSS اجراشده تلقی نمی‌شود.
- در صورت نصب Playwright، اجرای واقعی payload با alert marker قابل تأیید است.
- path reflection نیز پوشش داده می‌شود.

## IDOR
- access بدون احراز هویت و cross-account فقط با sessionهای تستی بررسی می‌شوند.
- شباهت صرف status/length برای نتیجه‌گیری کافی نیست؛ مقایسه‌ی محتوای محدودشده نیز انجام می‌شود.
- sequential-ID access به‌عنوان candidate و نیازمند بررسی مالکیت resource باقی می‌ماند.

## CORS / Redirect
- CORS با origin بی‌اعتماد تست می‌شود و wildcard با credentials به‌درستی تفسیر می‌شود.
- open redirect فقط وقتی ثبت می‌شود که پاسخ redirect واقعاً marker خارجی را در Location برگرداند.

## SSRF
- SSRF بازتاب‌شده/metadata با امضاهای مشخص بررسی می‌شود.
- OOB probe دیگر به‌تنهایی Finding تولید نمی‌کند؛ تا زمانی که callback خارجی مشاهده نشود، فقط telemetry است.

## Secrets
- placeholderهای رایج حذف می‌شوند.
- برای generic secretها entropy حداقلی اعمال می‌شود.
- مقدار کامل secret هرگز در evidence ذخیره نمی‌شود.

## Nuclei
- خروجی JSON خط‌به‌خط parse می‌شود.
- matchهای تکراری در یک اجرا group می‌شوند تا نویز کم شود.
- فقط severityهای medium/high/critical به FindingsStore می‌روند.

## Template Forge
- templateهای AI-generated بدون اجرای واقعی Finding نمی‌سازند.
- فقط templateی که با nuclei واقعاً match بدهد به‌عنوان confirmed finding ثبت می‌شود.
- validation و safe template id همچنان اجباری است.
