# Bug Bounty Agent — Final Queue + Verification Upgrade

## تغییرات نهایی
- مسیر ProjectDiscovery httpx به‌صورت امن probe می‌شود و `~/go/bin/httpx` بر executable همنام Python در venv اولویت دارد. override با `PROJECTDISCOVERY_HTTPX` حفظ شده است.
- TaskStore اکنون `run_id` و dedupe key دارد؛ Recon تکراری در همان run نمی‌تواند همان hunter/target/payload را بارها وارد صف کند.
- targetها قبل از dedupe canonical می‌شوند: scheme/host، slash انتهایی، query مرتب و fragment حذف می‌شود؛ `payload.url` نیز برای dedupe canonical می‌شود.
- آغاز هر اسکن، `todo/in_progress`های باقی‌مانده از اجرای قبلی را پاک می‌کند تا صف قدیمی و نیمه‌کاره به اجرای جدید سرایت نکند.
- یک اجرای جدید run_id تازه می‌گیرد، بنابراین full scan واقعی همچنان می‌تواند کارهای قبلی را دوباره تست کند؛ dedupe فقط در همان run اعمال می‌شود.
- FindingsStore یافته‌های منطقی تکراری را با dedupe key حذف می‌کند.
- Param Miner: چند baseline تصادفی، مقایسه status/body/length/redirect، حذف اختلاف‌های ناچیز، و reproducibility با probe دوم.
- Param Miner هرگز hidden parameter را به‌عنوان vulnerability verified علامت نمی‌زند؛ خروجی آن `candidate` است و verification دستی/تخصصی جداست.
- planning در برابر خطای موقت LLM یک retry محدود دارد و hunterهای ناشناخته یا proposalهای بدشکل را نادیده می‌گیرد.

## تست‌ها
- `pytest -q` → **14 passed**
- `python -m compileall -q .` → **pass**
- local HTTP smoke test برای Param Miner → **pass**؛ تغییر واقعی پاسخ برای `debug` کشف و به‌صورت candidate ثبت شد.
- تست انتخاب ProjectDiscovery httpx → **pass**
- تست migration دیتابیس قدیمی → **pass**
- تست dedupe در همان run → **pass**

## محدودیت تست محیط ساخت
در محیط ساخت، Python package `flask` نصب نبود و DNS/اتصال شبکهٔ مستقیم برای اجرای live scan روی `demo.owasp-juice.shop` در دسترس نبود. بنابراین Flask live-server و اجرای end-to-end شبکه‌ای روی Demo در این محیط انجام نشد. Source، compile، unit tests، DB migration و HTTP behavior محلی با موفقیت بررسی شدند. صفحهٔ رسمی OWASP نیز Juice Shop را یک برنامهٔ عمداً ناامن برای training/demo و تست ابزارهای امنیتی معرفی می‌کند.


## v3 hardening — Recon loop + scope normalization
- ScopeGuard normalizes pasted scope URLs (for example `https://example.com/robots.txt`) to hostname patterns before matching.
- Dashboard domain add uses the same normalization, so the UI stores `example.com` rather than a path-bearing URL.
- Recon is strictly host-level: any queued Recon target is collapsed to its hostname before subfinder/httpx/katana run.
- Initial Recon roots are de-duplicated, so `example.com`, `*.example.com`, and repeated entries cannot create duplicate root Recon jobs.
- TaskStore gives Recon a host-level dedupe identity and ignores incidental payload/reason fields, preventing LLM-generated `/robots.txt` and `/sitemap.xml` proposals from creating repeated Recon work.
- Planning uses `add_task_unique()` for all proposals and canonicalizes Recon proposals to hostnames before ScopeGuard enforcement.
- Regression suite: **29 passed**.
